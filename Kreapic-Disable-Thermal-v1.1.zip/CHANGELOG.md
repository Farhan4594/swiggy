<h1 align="center">Changelog</h1>

### Version 1.1

- Minor update
- Stabilization system

### Version 1.0

- Universal Initial Build Version 1.0
